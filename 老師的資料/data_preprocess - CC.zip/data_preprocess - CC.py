#coding:utf-8

import pandas as pd

combined_train_dataset_file_name = ".\\combined_train_dataset.csv"

print("Reading dataset files")

traindata_df = pd.read_csv(combined_train_dataset_file_name)

thrink_traindata_df = pd.DataFrame(traindata_df, columns=['CUST_NO', 'TXN_DT_FX','TXN_TIMES_FX','FX_TXN_AMT','TXN_DT_LN','TXN_TIMES_LN',
                                                          'LN_AMT','TXN_DT_WM','TXN_TIMES_WM','WM_TXN_AMT'])

print("Join dataframes")
traindata_df = pd.read_csv(".\\dataset\\TBN_RECENT_DT.csv", dtype={"CC_RECENT_DT": float, 'FX_RECENT_DT':float, 'LN_RECENT_DT':float, 'WM_RECENT_DT':float})
    
joined_traindata_df = traindata_df.set_index('CUST_NO').join(thrink_traindata_df.set_index('CUST_NO'))
joined_traindata_df.reset_index(inplace=True)
    
d_rows = joined_traindata_df[joined_traindata_df['CUST_NO'].duplicated(keep='first')]
joined_traindata_df.drop(d_rows.index,axis=0,inplace=True)
joined_traindata_df = joined_traindata_df.fillna(0)
    
joined_traindata_df.to_csv('CC_combined_train_dataset.csv', sep=',', index=False)

print(joined_traindata_df[:10])

print("combine train data done")
     
testdata_file_name = ".\\dataset\\TBN_Y_ZERO.csv"
testdata_df = pd.read_csv(testdata_file_name, dtype={"CUST_NO":str})
    
testdata_df = testdata_df.drop(['CC_IND', 'FX_IND', 'LN_IND', 'WM_IND'], axis=1)
testdata_df.to_csv('testdata_df_dataset.csv', sep=',', index=False)

joined_testdata_df = testdata_df.set_index('CUST_NO').join(joined_traindata_df.set_index('CUST_NO'))
joined_testdata_df.reset_index(inplace=True)

testdata_df = pd.read_csv('testdata_df_dataset.csv', dtype={"CUST_NO":str})

joined_testdata_df = testdata_df.merge(joined_testdata_df, on='CUST_NO')

print(joined_testdata_df[:10])
joined_testdata_df.to_csv('CC_combined_test_dataset.csv', sep=',', index=False)

print("combine test data done")