import pandas as pd
import numpy as np

from sklearn import preprocessing
from keras.models import Sequential 
from keras.layers import Convolution1D, MaxPooling1D 
from keras.layers import Flatten, Dense, Dropout

# Define model
model = Sequential()
model.add(Convolution1D(filters=256, kernel_size=2, activation="relu", input_shape=(9, 1)))
model.add(MaxPooling1D(strides=1))
model.add(Dropout(0.2810148240094146))

model.add(Convolution1D(filters=32, kernel_size=2, activation='relu'))
model.add(MaxPooling1D(strides=1))
model.add(Dropout(0.6194158005548608))

model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))

# define training parameters
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# load model
try:
    model.load_weights("tbn_cc_cnn.h5")
    print("success")
except:
    print("error")

# Read test data
test_df = pd.read_csv("CC_combined_test_dataset.csv", dtype={"CUST_NO": str})
test_df = test_df.drop(['CUST_NO'], axis=1)
test_df = test_df.drop(['WM_RECENT_DT'], axis=1)
test_df = test_df.drop(['CC_RECENT_DT'], axis=1)
test_df = test_df.drop(['FX_RECENT_DT'], axis=1)
test_df = test_df.drop(['LN_RECENT_DT'], axis=1)

test_df = test_df.apply(pd.to_numeric)
test_df = test_df.fillna(0)

# From pandas dataframe to np array & get features
features = test_df.values
print(features.shape)

nb_features = len(features)
 
# Normalize features
minmax_scale = preprocessing.MinMaxScaler(feature_range=(0,1))
normalizedFeatures = minmax_scale.fit_transform(features)

# reshape validation data
X_test = np.zeros((len(normalizedFeatures), 9, 1))
X_test[:, :, 0] = normalizedFeatures[:, :nb_features]

# Predict
predict = model.predict(X_test)

# Write prediction into files
test_pred_df = pd.read_csv("TBN_Y_ZERO.csv")
for i in range(predict.size):
    if predict[i] >= 0.735:
        test_pred_df.loc[i, 'CC_IND'] = 1
    else:
        test_pred_df.loc[i, 'CC_IND'] = 0
    
test_pred_df.to_csv("TBN_Y_ZERO.csv", index=False)
        